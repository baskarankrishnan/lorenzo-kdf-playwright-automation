﻿// pageHome
export const tab_Patients = "//td[@title='Patients']";
export const tab_MyWork = "//td[@title='My work']";
export const tab_InTheatre = "//td[@title='In theatre']";
export const lnkTaskPaneMyWork = "//div[@atei='Expand Pane - My work']//span[text()='<variable>']";
export const lnkSubTaskPaneInpatient = "(//div[contains(@atei,'Inpatient')]//span[text()='<variable>'])[2]";
export const lnkSubTaskPaneInpatientWithPAT = "//div[contains(@atei,'Inpatient')]//span[text()='<variable>']";
export const lnkSubTaskPaneEmerCurrentView = "//div[contains(@atei,'Current view')]//span[text()='<variable>']";
export const lnkSubTaskPaneTheatre = "//div[contains(@atei,'Theatre')]//span[text()='<variable>']";
export const lnkSubTaskPaneMedication = "//div[contains(@atei,'Medication')]//span[text()='<variable>']";
export const lnkTaskPanePatient = "//span[normalize-space()='Find record']";
export const txt_Identifier = "//input[@title='Enter an identifier']";
export const btn_Find = "//button[@title='Click to Find']";
export const btn_Logout = "//img[@title='Exit']";
export const txt_Yes = "//td[@title='Yes']";
export const btn_Login = "//input[@id='btnSubmit']";
export const lnk_Intray = "//span[normalize-space()='In-tray']";
export const btn_Findrecord = "//span[normalize-space()='Find record']";
export const tab_Mywork = "//td[@caption='Patients'][@key='TB_PATNT']";
export const lbl_popup = "//p['Question - LORENZO']";
export const btn_Yes = "//td[@title='Yes']";
export const tab_Clinic = "(//span[@class='T_PL'][normalize-space()='Clinics'])[1]";
export const txt_Clinicname = "//input[@dikey='itxtClinicname']";
export const SelectSession = "//img[@alt='Click to select row' and @title='Click to select row']";
export const btn_OK = "//td[contains(@title,'OK')]";
export const lnk_Book = "//span[@class='T_PL' and normalize-space(text())='Book']";
export const lnk_ClinicsSubLink = "//span[normalize-space()='Edit Booking']";
export const lnk_ManageAppointmentStatus = "//li[@id='itTT_C20_4']//span[contains(@class,'T_PL')][normalize-space()='Manage Appointment Status']";
export const lnk_Theatre = "//span[normalize-space()='Theatre']";
export const lnk_BookTheatre = "//span[normalize-space()='Book']";
export const tab_Bookingdetails = "//nobr[normalize-space()='Booking details']";
export const ink_Modifybooking = "//span[normalize-space()='Modify booking']";
export const tab_Intheatre = "//td[@title='In theatre']";
export const btn_Clinicalnote = "//td[@id='ieprtab_Tab_C5_iepr_Tabs_C5_15']";
export const lnk_Createnote = "//span[normalize-space()='Create note']";
export const sli_Splittericon = "//div[@id='divSplitter']";
export const txt_Notenameverify = "//label[@dikey='ilblShowTemplateName']";
export const lnk_printnote = "//span[normalize-space()='Print note']";
export const btn_Letters = "//td[@id='ieprtab_Tab_C5_iepr_Tabs_C5_18']";
export const lnk_Createdocument = "//li[@key='MN_DOC_CREATE']";
export const lnk_printdocument = "//span[normalize-space()='Print document']";
export const txt_Formsnameverify = "//label[@dikey='lblName']";
export const lnk_Formscontinue = "//span[normalize-space()='Continue']";
export const lnk_Correct = "//span[normalize-space()='Correct']";
export const lnk_FormsFinalise = "//span[normalize-space()='Finalise Form']";
export const lnk_Copyform = "//span[normalize-space()='Copy form']";
export const icn_filterRiteria = "//img[@title='Select a filter criteria']";
export const cmb_Struckout = "//td[@title='Struck out' and text()='Struck out']";
export const tab_Detailstab = "//nobr[contains(., 'Details')]";
export const txt_Formstatus2 = "//textarea[@id='it_C_C13' and @dikey='txtStatus']";
export const lnk_Printform = "//span[normalize-space()='Print Form']";
export const btn_Logout_10 = "//img[@title='Exit']";
export const txt_Yes_10 = "//td[@title='Yes']";
export const btn_Logout_11 = "//img[@title='Exit']";
export const txt_Yes_11 = "//td[@title='Yes']";
export const btn_Logout_12 = "//img[@title='Exit']";
export const txt_Yes_12 = "//td[@title='Yes']";
export const lnk_RecordAlert = "//li[@title = 'Record alert']";
export const lnk_ModifyAlert = "//li[@title='Modify alert']";
export const lnk_CloseAlert = "//li[@title='Close alert']";
export const lnk_ReOpenAlert = "//li[@title='Re-open alert']";
export const lnk_StrikeOutAlert = "//li[@title='Strikeout alert']";
export const lnk_RecordAllergy = "//li[@title='Record allergy/ADR']";
export const lnk_ModifyAllergy = "//li[@title='Modify allergy/ADR']";
export const lnk_CloseAllergy = "//li[@title='Close allergy/ADR']";
export const lnk_ReOpenAllergy = "//li[@title='Re-open allergy/ADR']";
export const lnk_StrikeOutAllergy = "//li[@title='Strikeout allergy/ADR']";
// pagePatientsTabBasicSearch
export const txt_Surname = "//input[@dikey='itxtSurname']";
export const txt_Forename = "//input[@dikey='itxtForename']";
export const cmb_Gender = "//label[text()='Gender']";
export const lbl_Gender = "//input[@title='Enter a gender value']";
export const txt_DOB = "//input[@class='DP_TB_Text']";
export const btn_Find = "//button[@title='Click to Find']";
export const cmb_identifiertype = "//img[@title='Select an  identifier type']";
export const txt_Identifier = "//input[@title='Enter an identifier']";
export const lbl_Identifier = "//label[@title='Identifier']";
export const btn_OK = "//button[@title='Click to add the selected patient']";
export const btn_OpProfileSFSimage = "//img[@tooltip='Please select an operation profile']";
export const txt_OpProfileSFSOPProfilename = "//input[@title='Please enter a code for operation profile name']";
export const btn_SFSFind = "//td[@title='Click to find']";
export const tbl_SFSFirstRow = "//table[@id='TableResultGrid']//td[@tabindex='0']";
export const btn_SFSOk = "//img[@title='Ok']";
export const btn_Next = "//img[@title='Next']";
export const cmb_Priority = "//table[@dikey='cbPriority']";
export const btn_Finish = "//td[@title='Finish']";
export const lbl_DOB = "//label[@dikey = 'ilblDOB']";
export const txt_DOB_10 = "//table[@title = 'Enter a value for date of birth']/descendant::input";
export const txt_DOB_11 = "//img[@title='Enter a gender value']";
export const txt_DOB_12 = "//input[@class='DP_TB_Text']";
export const txt_DOB_13 = "//img[@title='Enter a gender value']";
export const txt_DOB_14 = "//input[@class='DP_TB_Text']";
export const btn_Find_10 = "//button[@title='Click to Find']";
// pageRegConfirmationpopup
export const btn_PopUpOk = "//td[@class='Cmd_TTE'][@title='Ok']";
export const btn_DocTempCancel = "//td[@title = 'Cancel']"
export const lbl_PatientBookBanner = "(//td[@class='CxtBar_TD6'])[1]";
export const btn_ProceduresInterventions = "//td[@tabaccesskey='P']"
export const lnk_RecordProcedure = "//li[@title='Record procedure']"
export const txt_ProcedureName = "//td[@icna = 'Name']"
export const txt_ProcedureStatus = "//td[@icna = 'Status']"
export const txt_ProcedurePerformedDate = "//td[@icna = 'PerformedDateTime']"
// pageHistoryTab
export const tab_Alerts = "//nobr[text()='Alerts']/parent::td";
export const tab_Allergies = "//nobr[text()='Allergies/ADRs']/parent::td";
export const tab_Problems = "//nobr[text()='Problems']/parent::td";
// pageLIMainViewResource
export const chk_DisplayInactiveAllergies = "//td[@caption='Display inactive allergies/ADRs']";
export const chk_DisplayStruckoutAllergies = "//td[@caption='Display struck out allergies/ADRs']";
export const txt_AllergyStatus = "//td[@icn = 'AllergyStatus']/span";
export const txt_Allergytype = "//td[@icn = 'AllergyType']/span";
export const txt_Allergen_LV = "(//td[@icn = 'Allergen']/span)[2]";
export const txt_Allergy_InfoSource = "//td[@icn = 'InformationSource']/span";
export const txt_Allergy_OnsetDate = "//td[@icn = 'OnSetDttm']/span";
// pageRiskListView
export const chk_DisplayInactiveAlert = "//td[normalize-space()='Display inactive alert']";
export const chk_DisplayStruckoutAlert = "//td[normalize-space()='Display struck out alert']";
export const txt_Alerttype = "//td[@icna = 'Risk Type']";
export const txt_Alertname = "//td[@icna = 'Risk Name']";
export const txt_InformationSource = "//td[@icna = 'Information Source']";
export const txt_AlertStatus = "//td[@icna = 'Status']";